namespace Library.Web;

public class UiOperationStatus {
    public string? Message { get; set; }
    public UiResultType Type { get; set; }
}
