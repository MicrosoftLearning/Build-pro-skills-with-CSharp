namespace Library.Web;

public enum UiResultType {
    Success,
    Failure,
    Error
}