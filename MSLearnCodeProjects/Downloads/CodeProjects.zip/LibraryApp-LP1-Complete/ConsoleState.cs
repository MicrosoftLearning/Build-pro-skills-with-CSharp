﻿namespace LibraryApp.ConsoleApp;

public enum ConsoleState
{
    PatronSearch,
    PatronSearchResults,
    PatronDetails,
    LoanDetails,
    Quit
}